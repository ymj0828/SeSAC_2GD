const initialState = {
  list: [
    {
      id: 0,
      text: "리액트 공부하기",
      done: false,
    },
    {
      id: 1,
      text: "척추의 요정이 말합니다! 척추 펴기!",
      done: false,
    },
    {
      id: 2,
      text: "운동하기",
      done: false,
    },
  ],
};

const CREATE = "todo/CREATE";
const DONE = "todo/DONE";

export function create(payload) {
  return {
    type: CREATE,
    payload, //object
  };
}
export function done(id) {
  return {
    type: DONE,
    id, // number
  };
}

export function todo(state = initialState, action) {
  /* 
  action = {
    type:'todo/CREATE',
    payload:{
      id:3,
      text:'점심먹기'
    }
  }
  */
  switch (action.type) {
    case CREATE:
      return{
        ...state,
        list: state.list.concat({
          id: action.payload.id,
          text:action.payload.text,
          done:false,
        })
      }
    case DONE:
      return state;
      break;
    default:
      return state;
  }
}
