import { useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { create, done } from '../store/modules/todo'

export default function TodoList() {
  const list = useSelector((state) => state.todo.list);
  const input = useRef();
  const dispatch = useDispatch();
  return (
    <>
      <h1>TodoList</h1>
      <div>
        <input type="text" ref={input} />
        <button onClick={() => dispatch(create({id:list.length, text:input.current.value}))}>추가</button>
      </div>
      <ul>
        {list.map((el) => {
          return (
            <li key={el.id}>
              {el.text}
              <button onClick={() => dispatch(done(""))}>완료</button>
            </li>
          );
        })}
      </ul>
    </>
  );
}
