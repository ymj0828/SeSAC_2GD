import ListContainer from "./components/ListContainer";

function App() {
  return (
    <>
      <ListContainer></ListContainer>
    </>
  );
}

export default App;
